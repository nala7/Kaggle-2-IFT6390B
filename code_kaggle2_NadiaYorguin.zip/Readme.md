# IFT6390B - Second Kaggle Competition Report

## Team members

Team name: Nadia + Yorguin

### Members

- Nadia Gonzalez Fernandez
- Yorguin José Mantilla Ramos

## Data preparation

The scripts and notebooks assume that the data is in a data subfolder:

test_path = 'data/test_data.pkl'
train_path = 'data/train_data.pkl'

## Milestone 1

Run the Milestone1.ipynb notebook. It has both the SVM and the CNN models from scratch.

## Milestone 2

For milestone 2, each of the models has its own python script. The scripts were run on a local laptop with a GPU (Nvidia GeForce RTX 4070). 

The models and scripts are:

- Simple CNN in Pytorch : Milestone2_A_Simple_CNN_in_pytorch.py
- Pretrained ResNet-18 : Milestone2_B_Pretrained_ResNet-18.py
- Hierarchical Multi-Stage ResNet-18 Pipeline - Milestone2_C_Hierarchical_Multi-Stage_ResNet-18_Pipeline.py
- Pretrained ResNet-18 (+Modifications) : Milestone2_D_Pretrained_ResNet-18_and_EfficientNet-B0.py
- Pretrained EfficientNet-B0 : Milestone2_D_Pretrained_ResNet-18_and_EfficientNet-B0.py
- Weighted Voting : Milestone2_E_Weighted_Voting.py

It is advised to clean the folder from other models checkpoints and results before running each script to avoid confusion on the filenames (and loading the wrong model).

An environment file is provided to install the necessary libraries. The environment file is called `environment.yml`. The python version used is Python 3.11.7 . Alternatively, a pip list is provided in the file `piplist.txt`.

### Special Indications

For Pretrained ResNet-18 (+Modifications) and Pretrained EfficientNet-B0 the same script it used, but a variable is changed around lines 29-31:

```python
# Choose between "resnet18" and "efficientnet_b0"
selected_model = "resnet18"  
#selected_model = 'efficientnet_b0'
```

For Weighted Voting it is assumed that the files Pretrained Resnet-18, Pretrained ResNet-18 (+Modifications) and Pretrained EfficientNet-B0 have been run before. The script will load the predictions of the models and do the voting.

So, for this purpose dont clean the following files:

- 'test_predictions2_resnet18_Entire.csv'
- 'test_predictions2_efficientnet_b0_Entire.csv'
- 'test_predictions_pretrained.csv'
